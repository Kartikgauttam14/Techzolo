"use client";

import React, { useEffect, useRef } from 'react';
import Spline from '@splinetool/react-spline';
import { Button } from "@/components/ui/button"
import { ArrowRight, User, LogOut, Settings } from "lucide-react"
import Link from "next/link"
import { useAuth } from "@/hooks/use-auth"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useRouter } from "next/navigation"

function HeroSplineBackground() {
  return (
    <div style={{
      position: 'relative',
      width: '100%',
      height: '100vh',
      pointerEvents: 'auto',
      overflow: 'hidden',
    }}>
      <Spline
        style={{
          width: '100%',
          height: '100vh',
          pointerEvents: 'auto',
        }}
        scene="https://prod.spline.design/dJqTIQ-tE3ULUPMi/scene.splinecode"
      />
      <div
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100vh',
          background: `
            linear-gradient(to right, rgba(0, 0, 0, 0.8), transparent 30%, transparent 70%, rgba(0, 0, 0, 0.8)),
            linear-gradient(to bottom, transparent 50%, rgba(0, 0, 0, 0.9))
          `,
          pointerEvents: 'none',
        }}
      />
    </div>
  );
}

function ScreenshotSection({ screenshotRef }: { screenshotRef: React.RefObject<HTMLDivElement | null> }) {
  return (
    <section className="relative z-10 px-4 md:px-6 lg:px-8 mt-11 md:mt-12">
      <div ref={screenshotRef} className="bg-gray-900 rounded-xl overflow-hidden shadow-2xl border border-gray-700/50 w-full md:w-[80%] lg:w-[70%] mx-auto">
        <div>
          <img
            src="https://cdn.sanity.io/images/s6lu43cv/production-v4/13b6177b537aee0fc311a867ea938f16416e8670-3840x2160.jpg?w=3840&h=2160&q=10&auto=format&fm=jpg"
            alt="App Screenshot"
            className="w-full h-auto block rounded-lg mx-auto"
          />
        </div>
      </div>
    </section>
  );
}

function HeroContent() {
  return (
    <div className="text-white px-4 w-full flex flex-col lg:flex-row justify-between items-start lg:items-center">

      <div className="w-full lg:w-1/2 pr-0 lg:pr-8 mb-8 lg:mb-0">
        <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-4 leading-tight tracking-wide">
          We're Building<br />Cool Experiences
        </h1>
        <div className="text-sm text-gray-300 opacity-90 mt-4">
          AI \ WEB3 \ UI \ 3D \ MOTION
        </div>
      </div>

      <div className="w-full lg:w-1/2 pl-0 lg:pl-8 flex flex-col items-start">
         <p className="text-base sm:text-lg opacity-80 mb-6 max-w-md">
           Crafting Awesome Stories and Killer Designs to Make Brand Stand Out
        </p>
        <div className="flex pointer-events-auto flex-col sm:flex-row items-start space-y-3 sm:space-y-0 sm:space-x-3">
             <button className="border border-white text-white font-semibold py-2.5 sm:py-3.5 px-6 sm:px-8 rounded-2xl transition duration-300 w-full sm:w-auto hover:bg-white hover:text-black">
                Contact Us
            </button>
            <button className="pointer-events-auto bg-white text-black font-semibold py-2.5 sm:py-3.5 px-6 sm:px-8 rounded-2xl transition duration-300 hover:scale-105 flex items-center justify-center w-full sm:w-auto">
               <svg className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-cyan-400" fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                   <path d="M12 4C11.4477 4 11 4.44772 11 5V11H5C4.44772 11 4 11.4477 4 12C4 12.5523 4.44772 13 5 13H11V19C11 19.5523 11.4477 20 12 20C12.5523 20 13 19.5523 13 19V13H19C19.5523 13 20 12.5523 20 12C20 11.4477 19.5523 11 19 11H13V5C13 4.44772 12.5523 4 12 4Z" fill="currentColor" />
               </svg>
               Get Started
            </button>
        </div>
      </div>

    </div>
  );
}

function Navbar({ scrollToSection }: { scrollToSection: (sectionId: string) => void }) {
  const { user, isAuthenticated, logout, isLoading } = useAuth()
  const router = useRouter()

  const handleStartCreating = () => {
    scrollToSection("contact")
  }

  const handleProfileClick = () => {
    router.push("/profile")
  }

  const handleLogout = async () => {
    await logout()
  }

  const getInitials = (name: string) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const UserProfileDropdown = () => (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="relative h-8 w-8 rounded-full border-gray-300 bg-white/10 border-white/20">
          <Avatar className="h-8 w-8">
            <AvatarFallback className="bg-gradient-to-br from-rose-500 to-pink-500 text-white text-xs font-semibold">
              {getInitials(user?.full_name || "")}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-56" align="end" forceMount>
        <div className="flex items-center justify-start gap-2 p-2">
          <div className="flex flex-col space-y-1 leading-none">
            <p className="font-medium">{user?.full_name}</p>
            <p className="w-[200px] truncate text-sm text-muted-foreground">{user?.email}</p>
          </div>
        </div>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleProfileClick}>
          <User className="mr-2 h-4 w-4" />
          <span>Profile</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => router.push("/dashboard")}>
          <Settings className="mr-2 h-4 w-4" />
          <span>Dashboard</span>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Log out</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )

  return (
    <nav className="fixed top-0 left-0 right-0 z-20" style={{ backgroundColor: 'rgba(13, 13, 24, 0.3)', backdropFilter: 'blur(8px)', WebkitBackdropFilter: 'blur(8px)', borderRadius: '0 0 0.75rem 0.75rem' }}>
      <div className="px-4 py-4 md:px-6 lg:px-8 flex items-center justify-between">
        <div className="flex items-center space-x-6 lg:space-x-8">
          <div className="text-white cursor-pointer" style={{ width: '32px', height: '32px' }} onClick={() => window.location.reload()}>
             <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path fillRule="evenodd" clipRule="evenodd" d="M16 32C24.8366 32 32 24.8366 32 16C32 7.16344 24.8366 0 16 0C7.16344 0 0 7.16344 0 16C0 24.8366 7.16344 32 16 32ZM12.4306 9.70695C12.742 9.33317 13.2633 9.30058 13.6052 9.62118L19.1798 14.8165C19.4894 15.1054 19.4894 15.5841 19.1798 15.873L13.6052 21.0683C13.2633 21.3889 12.742 21.3563 12.4306 19.9991V9.70695Z" fill="currentColor" />
            </svg>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            <button onClick={() => scrollToSection("services")} className="text-gray-300 hover:text-white text-sm transition duration-150">Services</button>
            <button onClick={() => scrollToSection("portfolio")} className="text-gray-300 hover:text-white text-sm transition duration-150">Portfolio</button>
            <button onClick={() => scrollToSection("testimonials")} className="text-gray-300 hover:text-white text-sm transition duration-150">Testimonials</button>
            <button onClick={() => scrollToSection("blog")} className="text-gray-300 hover:text-white text-sm transition duration-150">Resources</button>
            <button onClick={() => scrollToSection("contact")} className="text-gray-300 hover:text-white text-sm transition duration-150">Contact</button>
          </div>
        </div>

        <div className="flex items-center space-x-4">
          {!isLoading && (
            <> {isAuthenticated && user ? (
              <Button size="sm" className="bg-primary hover:bg-primary/90 text-white text-sm font-medium px-4 py-2 rounded-full" onClick={handleStartCreating}>
                Start creating<ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            ) : (
              <> 
                <Link href="/auth/login"><Button variant="outline" size="sm" className="text-sm font-medium border-white/20 hover:border-white/40 text-white hover:text-white bg-white/10 hover:bg-white/20">Log In</Button></Link>
                <Link href="/auth/signup"><Button className="bg-primary hover:bg-primary/90 text-white text-sm font-medium px-4 py-2 rounded-full" size="sm">Sign Up<ArrowRight className="ml-2 h-4 w-4" /></Button></Link>
              </>
            )} </>
          )}
          {isAuthenticated && user && (
            <UserProfileDropdown />
          )}
        </div>
      </div>
    </nav>
  );
}

const HeroSection = ({ scrollToSection }: { scrollToSection: (sectionId: string) => void }) => {
  const screenshotRef = useRef<HTMLDivElement>(null);
  const heroContentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;

      if (screenshotRef.current && heroContentRef.current) {
        const screenshotElement = screenshotRef.current;
        const heroContentElement = heroContentRef.current;

        // Parallax effect for screenshot
        const screenshotTransform = Math.min(scrollPosition * 0.5, 100);
        screenshotElement.style.transform = `translateY(${screenshotTransform}px)`;

        // Fade out effect for hero content
        const opacity = Math.max(1 - scrollPosition / windowHeight, 0);
        heroContentElement.style.opacity = opacity.toString();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative h-screen bg-black overflow-hidden">
      <HeroSplineBackground />
      
      <div className="absolute inset-0 z-10 flex flex-col">
        <Navbar scrollToSection={scrollToSection} />
        
        <div ref={heroContentRef} className="flex-1 flex items-center justify-center">
          <HeroContent />
        </div>
        
        <ScreenshotSection screenshotRef={screenshotRef} />
      </div>
    </div>
  );
};

export default HeroSection;